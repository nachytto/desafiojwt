SELECT * FROM usuarios;
