export const URLBASE = 'http://localhost:3000'

export const ENDPOINT = {
  login: `${URLBASE}/login`,
  users: `${URLBASE}/usuarios`
}
